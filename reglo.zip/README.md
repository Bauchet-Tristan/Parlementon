##Reglo Bold

Reglo Bold is a geometric Sans designed by Sebastien Sanfilippo. Reglo Bold was initially designed for the identity of Radio Panik with Open Source Publishing. 

##Contribute
#####Recommendations:
1. Improve spacing
2. Improve kerning
3. Add missing glyphs

##Font specimen
www.love-letters.be

##License

Reglo Bold is licensed under the SIL Open Font License v1.1 (http://scripts.sil.org/OFL)

To view the copyright and specific terms and conditions please refer to [OFL.txt.](OFL.txt)

